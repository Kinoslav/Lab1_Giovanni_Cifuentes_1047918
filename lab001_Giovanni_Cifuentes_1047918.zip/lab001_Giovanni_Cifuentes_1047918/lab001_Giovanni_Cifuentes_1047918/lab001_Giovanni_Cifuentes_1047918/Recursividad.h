#pragma once
ref class Recursividad
{
public:
	Recursividad();
public:
	int fibonacci(int num);
public:
	int Factorial(int n);
public:
	long binario(long n);
};

