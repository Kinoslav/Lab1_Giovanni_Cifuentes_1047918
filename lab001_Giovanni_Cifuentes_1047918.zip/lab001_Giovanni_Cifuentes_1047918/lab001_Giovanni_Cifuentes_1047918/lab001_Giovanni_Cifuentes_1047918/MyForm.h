#pragma once
#include "Recursividad.h"

namespace lab001_Giovanni_Cifuentes_1047918 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;

	/// <summary>
	/// Resumen de MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  fiboncacciBtn;
	private: System::Windows::Forms::TextBox^  textBoxfibonacci;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^ factorialbt;
	private: System::Windows::Forms::TextBox^ factorialtxt;


	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::TextBox^ binariotxt;
	private: System::Windows::Forms::Button^ binariobt;
	protected:

	protected:

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->fiboncacciBtn = (gcnew System::Windows::Forms::Button());
			this->textBoxfibonacci = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->factorialbt = (gcnew System::Windows::Forms::Button());
			this->factorialtxt = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->binariotxt = (gcnew System::Windows::Forms::TextBox());
			this->binariobt = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// fiboncacciBtn
			// 
			this->fiboncacciBtn->Location = System::Drawing::Point(239, 133);
			this->fiboncacciBtn->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->fiboncacciBtn->Name = L"fiboncacciBtn";
			this->fiboncacciBtn->Size = System::Drawing::Size(112, 57);
			this->fiboncacciBtn->TabIndex = 0;
			this->fiboncacciBtn->Text = L"FIbonacci";
			this->fiboncacciBtn->UseVisualStyleBackColor = true;
			this->fiboncacciBtn->Click += gcnew System::EventHandler(this, &MyForm::fiboncacciBtn_Click);
			// 
			// textBoxfibonacci
			// 
			this->textBoxfibonacci->Location = System::Drawing::Point(220, 97);
			this->textBoxfibonacci->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->textBoxfibonacci->Name = L"textBoxfibonacci";
			this->textBoxfibonacci->Size = System::Drawing::Size(148, 26);
			this->textBoxfibonacci->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(18, 102);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(193, 20);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Ingrese n�mero Fibonacci";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(60, 286);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(0, 20);
			this->label2->TabIndex = 3;
			// 
			// factorialbt
			// 
			this->factorialbt->Location = System::Drawing::Point(233, 248);
			this->factorialbt->Name = L"factorialbt";
			this->factorialbt->Size = System::Drawing::Size(118, 45);
			this->factorialbt->TabIndex = 4;
			this->factorialbt->Text = L"Factorial";
			this->factorialbt->UseVisualStyleBackColor = true;
			this->factorialbt->Click += gcnew System::EventHandler(this, &MyForm::Factorialbt_Click);
			// 
			// factorialtxt
			// 
			this->factorialtxt->Location = System::Drawing::Point(232, 210);
			this->factorialtxt->Name = L"factorialtxt";
			this->factorialtxt->Size = System::Drawing::Size(148, 26);
			this->factorialtxt->TabIndex = 5;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(9, 216);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(217, 20);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Ingrese numero para factorial";
			this->label3->Click += gcnew System::EventHandler(this, &MyForm::Label3_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(27, 286);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(0, 20);
			this->label4->TabIndex = 7;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(18, 357);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(206, 20);
			this->label5->TabIndex = 8;
			this->label5->Text = L"Ingrese para volverlo binario";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(27, 405);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(0, 20);
			this->label6->TabIndex = 9;
			// 
			// binariotxt
			// 
			this->binariotxt->Location = System::Drawing::Point(239, 351);
			this->binariotxt->Name = L"binariotxt";
			this->binariotxt->Size = System::Drawing::Size(150, 26);
			this->binariotxt->TabIndex = 10;
			// 
			// binariobt
			// 
			this->binariobt->Location = System::Drawing::Point(232, 391);
			this->binariobt->Name = L"binariobt";
			this->binariobt->Size = System::Drawing::Size(118, 49);
			this->binariobt->TabIndex = 11;
			this->binariobt->Text = L"Binario";
			this->binariobt->UseVisualStyleBackColor = true;
			this->binariobt->Click += gcnew System::EventHandler(this, &MyForm::Binariobt_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(460, 500);
			this->Controls->Add(this->binariobt);
			this->Controls->Add(this->binariotxt);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->factorialtxt);
			this->Controls->Add(this->factorialbt);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textBoxfibonacci);
			this->Controls->Add(this->fiboncacciBtn);
			this->Margin = System::Windows::Forms::Padding(4, 5, 4, 5);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void fiboncacciBtn_Click(System::Object^  sender, System::EventArgs^  e) {
				 int num = System::Convert::ToInt32(textBoxfibonacci->Text);
				 Recursividad^ recursividadObj = gcnew Recursividad();
				 label2->Text = label2->Text + System::Convert::ToString(recursividadObj->fibonacci(num));
	}
	private: System::Void Label3_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void Factorialbt_Click(System::Object^ sender, System::EventArgs^ e) {
	int num = System::Convert::ToInt32(factorialtxt->Text);
	Recursividad^ recursividadobj = gcnew Recursividad();
	label4->Text = label4->Text + System::Convert::ToString(recursividadobj->Factorial(num));
}
private: System::Void Binariobt_Click(System::Object^ sender, System::EventArgs^ e) {
	long n = System::Convert::ToInt32(binariotxt->Text);
	Recursividad^ recursividadobj = gcnew Recursividad();
	label6->Text = label6->Text + System::Convert::ToString(recursividadobj->binario(n));
}
};
}
