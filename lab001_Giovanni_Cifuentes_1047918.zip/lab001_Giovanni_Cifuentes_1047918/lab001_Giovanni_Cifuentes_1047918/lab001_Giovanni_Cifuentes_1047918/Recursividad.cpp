#include "Recursividad.h"


Recursividad::Recursividad()
{
}
int Recursividad::fibonacci(int num){
	if (num <= 1){
		return 1;
	}
	else{
		return fibonacci(num - 1) + fibonacci(num - 2);
	}
}
int Recursividad::Factorial(int n){
	if (n < 0) {
		return 1;
	}
	else if (n > 1)
	{
		return n * Factorial(n - 1);
	}
	else
	{
		return 1;
	}

}
long Recursividad::binario(long n) {
	if (n < 2)
	{
		return n;
	}
	else
	{
		return n % 2 + (10 * binario(n / 2));
	}
}